package composite;

public class Director extends CompositeEmployee {
    public Director(int codigo, String nome, String cargo) {
        super(codigo, nome, cargo);
    }
}
