package composite;

public class Developer extends CompositeEmployee {
    public Developer(int codigo, String nome, String cargo) {
        super(codigo, nome, cargo);
    }
}
