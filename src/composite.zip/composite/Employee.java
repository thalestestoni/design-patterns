package composite;

public interface Employee {
    public void showEmployeeDetails();
}
